import './components/my-slideshow.js';
import { Slideshow } from './slideshow.js';

new Slideshow('slideshow', { delay: 2000 });
