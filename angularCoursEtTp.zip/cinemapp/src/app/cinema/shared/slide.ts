export interface Slide {
  id: number;
  movieId: number;
  imgSrc: string;
  imgSrcFull: string;
  imgAlt: string;
}
