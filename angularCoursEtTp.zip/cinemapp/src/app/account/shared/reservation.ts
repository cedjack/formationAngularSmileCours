export interface Reservation {
  movieTitle: string;
  theaterTitle: string;
  scheduleId: number;
  scheduleHour: string;
}
