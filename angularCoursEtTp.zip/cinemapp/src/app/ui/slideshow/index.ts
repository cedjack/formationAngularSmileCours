export { Slide }  from './slideshow/shared/slide';
export { SlideshowComponent }  from './slideshow/slideshow.component';
export { SlideComponent }  from './slideshow/slide/slide.component';
export { PaginationComponent }  from './pagination/pagination.component';
export { SlideshowModule } from './slideshow.module';
