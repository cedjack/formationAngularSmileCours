export interface Slide {
  id: number;
  link: string;
  imgSrc: string;
  imgSrcFull: string;
  imgAlt: string;
}
